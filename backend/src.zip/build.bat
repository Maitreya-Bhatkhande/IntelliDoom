@echo off
rem ---------------------------------------------------------------------------
rem build.bat  -  compiles the Kotlin backend into build\classes
rem
rem It uses the Kotlin compiler (kotlinc) and JDK that ship with your
rem Android Studio installation, so nothing extra needs to be installed.
rem The paths live right here - change them if you move Android Studio.
rem ---------------------------------------------------------------------------
setlocal

set "ANDROID_HOME=D:\Softwares\Android"
set "JAVA_HOME=%ANDROID_HOME%\jbr"
set "KOTLINC=%ANDROID_HOME%\plugins\Kotlin\kotlinc"

cd /d "%~dp0"

echo [build] compiling Kotlin sources...

if exist build\classes rmdir /s /q build\classes

rem  -cp                : where to find kotlinx-serialization + coroutines
rem  -Xplugin           : turns @Serializable classes into JSON code
rem  -jvm-target 21     : produce bytecode for Java 21+ (we run on the JDK 25
rem                       that Android Studio ships in the jbr\ folder)
"%KOTLINC%\bin\kotlinc.bat" src ^
    -cp "lib\kotlinx-serialization-core-jvm-1.11.0.jar;lib\kotlinx-serialization-json-jvm-1.11.0.jar;%KOTLINC%\lib\kotlinx-coroutines-core-jvm.jar" ^
    "-Xplugin=%KOTLINC%\lib\kotlin-serialization-compiler-plugin.jar" ^
    -jvm-target 21 ^
    -d build\classes

if errorlevel 1 (
    echo [build] FAILED - see the errors above.
    exit /b 1
)

echo [build] OK -^> build\classes
