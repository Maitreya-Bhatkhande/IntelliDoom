@echo off
rem ---------------------------------------------------------------------------
rem run.bat  -  starts the Kotlin backend on http://localhost:4000
rem
rem If you never compiled before (or just edited Kotlin code), run build.bat
rem first. This script compiles automatically when build\classes is missing.
rem ---------------------------------------------------------------------------
setlocal

set "ANDROID_HOME=D:\Softwares\Android"
set "JAVA_HOME=%ANDROID_HOME%\jbr"
set "KOTLINC=%ANDROID_HOME%\plugins\Kotlin\kotlinc"

cd /d "%~dp0"

if not exist build\classes (
    echo [run] build\classes not found - compiling first...
    call build.bat || exit /b 1
)

rem  build\classes              : our compiled Kotlin code
rem  lib\*                      : kotlinx-serialization (JSON support)
rem  %KOTLINC%\lib\kotlin-*.jar : Kotlin standard library + coroutines
"%JAVA_HOME%\bin\java.exe" -cp "build\classes;lib\*;%KOTLINC%\lib\kotlin-stdlib.jar;%KOTLINC%\lib\kotlinx-coroutines-core-jvm.jar;%KOTLINC%\lib\annotations-13.0.jar" com.intdoom.MainKt
