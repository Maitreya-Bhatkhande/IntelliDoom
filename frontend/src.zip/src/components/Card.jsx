// Card.jsx
// ---------------------------------------------------------------------------
// One full-screen card, kept deliberately minimal: a picture area on top and a
// small text block underneath (category, headline, optional abstract, source).
//
// The picture is always shown WHOLE - it is never stretched or cropped. A big
// blurry copy of the same image fills the space behind it, so the card still
// feels full and colourful. Clicking anywhere on the card opens the link.
// ---------------------------------------------------------------------------

import { TOPIC_LABELS, TOPIC_GLYPHS, TYPE_LABELS } from "../labels.js";

export default function Card({ item }) {
  function openLink() {
    window.open(item.url, "_blank", "noreferrer");
  }

  // If an image URL is broken we just hide that <img>; the card still works.
  function hideBroken(event) {
    event.currentTarget.style.display = "none";
  }

  const topic = TOPIC_LABELS[item.topic] ?? item.topic;
  const type = TYPE_LABELS[item.type] ?? item.type;
  const glyph = TOPIC_GLYPHS[item.topic] ?? "◆";

  return (
    <article className="card" onClick={openLink} title={item.title}>
      {item.image ? (
        <div className="card-media">
          {/* Blurred backdrop: fills the area with the image's own colours. */}
          <img
            className="card-glow"
            src={item.image}
            alt=""
            aria-hidden="true"
            onError={hideBroken}
          />
          {/* The real image, shown in full and never distorted. */}
          <img
            className="card-image"
            src={item.image}
            alt=""
            loading="lazy"
            onError={hideBroken}
          />
        </div>
      ) : (
        <div className="card-glyph">{glyph}</div>
      )}

      <div className="card-body">
        <p className="card-meta">
          <span className="card-topic">{topic}</span>
          <span className="card-sep">/</span>
          {type}
        </p>

        <h2 className="card-title">{item.title}</h2>

        {item.description && <p className="card-desc">{item.description}</p>}

        <p className="card-foot">
          <span className="card-source">
            {item.source}
            {item.score ? ` · ▲ ${item.score}` : ""}
          </span>
          <span className="card-open">Open ↗</span>
        </p>
      </div>
    </article>
  );
}
